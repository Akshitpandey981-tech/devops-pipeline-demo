# 👋 Hi, I’m Akshit Pandey  

🎯 Aspiring **DevOps Engineer** passionate about cloud, automation, and CI/CD.  
💼 Currently working as **Analyst at Eclerx** | B.Tech (2023, CGC Jhanjeri)  

## 🚀 Tech Stack
🛠️ DevOps Tools: Docker | Jenkins | Kubernetes | AWS | Ansible | Terraform  
💻 Programming: C | C++ | JavaScript | Python (basic)  
☁️ Cloud Platforms: AWS (EC2, S3, IAM, Route 53)  
🧠 Databases: MySQL | MongoDB  
🌐 Web: HTML | CSS | JS | Node.js (basics)  

## 📂 Featured Projects
🔹 [DevOps Pipeline Demo](https://github.com/Akshitpandey981-tech/devops-pipeline-demo)  
🔹 [AWS Deployment Lab](https://github.com/Akshitpandey981-tech/aws-deployment-lab)  

## 📫 Connect With Me
🔗 LinkedIn: [linkedin.com/in/akshit-pandey-294a85264](https://www.linkedin.com/in/akshit-pandey-294a85264)  
💻 GitHub: [github.com/Akshitpandey981-tech](https://github.com/Akshitpandey981-tech)  
📧 Email: akshitpandey981@gmail.com  

⭐ *Thanks for visiting my profile! I’m continuously learning and building DevOps projects.*
