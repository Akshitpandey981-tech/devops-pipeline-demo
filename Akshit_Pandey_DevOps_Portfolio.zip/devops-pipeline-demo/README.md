# DevOps Pipeline Demo 🚀
This project demonstrates a simple **CI/CD pipeline** using **Jenkins, Docker, and GitHub** for automating builds, testing, and deployments.

## 🧰 Tools Used
- Jenkins
- Docker
- GitHub
- Linux (Ubuntu)
- Node.js (sample app)

## 🏗️ Pipeline Overview
1. Developer pushes code to GitHub
2. Jenkins pulls the latest code
3. Jenkins builds the Docker image
4. Container runs the app automatically

## 🧪 How to Run
1. Install Docker and Jenkins
2. Start Jenkins and connect it to GitHub
3. Create a Jenkins pipeline job
4. Use the provided Jenkinsfile
5. Run the build — Jenkins will build and deploy the container

## 📝 Sample Jenkinsfile
```groovy
pipeline {
    agent any
    stages {
        stage('Clone Repository') {
            steps {
                git 'https://github.com/Akshitpandey981-tech/devops-pipeline-demo.git'
            }
        }
        stage('Build Docker Image') {
            steps {
                sh 'docker build -t devops-demo .'
            }
        }
        stage('Run Container') {
            steps {
                sh 'docker run -d -p 8080:80 devops-demo'
            }
        }
    }
}
```

## 🐳 Dockerfile
```dockerfile
FROM nginx:latest
COPY app /usr/share/nginx/html
EXPOSE 80
```

👤 Created by: [Akshit Pandey](https://www.linkedin.com/in/akshit-pandey-294a85264)
🔗 GitHub: [Akshitpandey981-tech](https://github.com/Akshitpandey981-tech)
