# AWS Deployment Lab ☁️
This project demonstrates how to **deploy a static website on AWS** using **EC2, S3, and Route 53**.

## 🧰 Tools Used
- AWS EC2
- AWS S3
- AWS Route 53
- Linux (Ubuntu)
- Nginx

## 🧱 Steps to Deploy
1. Launch an EC2 instance (Ubuntu)
2. Connect using SSH
3. Install Nginx
```bash
sudo apt update
sudo apt install nginx -y
```
4. Copy your `index.html` file to the Nginx directory
```bash
sudo cp index.html /var/www/html/
```
5. Open your EC2 public IP in the browser to view your hosted page

## 🧾 index.html Example
```html
<!DOCTYPE html>
<html>
<head>
  <title>Akshit Pandey - AWS Deployment Demo</title>
</head>
<body>
  <h1>Welcome to My AWS Deployment Lab!</h1>
  <p>This static site is hosted on AWS EC2 using Nginx.</p>
</body>
</html>
```
👤 Created by: [Akshit Pandey](https://www.linkedin.com/in/akshit-pandey-294a85264)
🔗 GitHub: [Akshitpandey981-tech](https://github.com/Akshitpandey981-tech)
